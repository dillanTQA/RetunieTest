import { useSuppliers } from "@/hooks/use-triage";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronLeft, Star, Building2, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { clsx } from "clsx";
import { Loader2 } from "lucide-react";

interface TriageSuppliersProps {
  requestId: number;
  onNext: () => void;
  onBack: () => void;
}

export default function TriageSuppliers({ requestId, onNext, onBack }: TriageSuppliersProps) {
  // Hardcoded category for now, ideally comes from previous step
  const { data: suppliers, isLoading } = useSuppliers("sow");
  const [selectedSuppliers, setSelectedSuppliers] = useState<number[]>([]);

  const toggleSupplier = (id: number) => {
    setSelectedSuppliers(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-display font-bold">Select Suppliers</h2>
        <p className="text-muted-foreground">Choose up to 3 suppliers to invite for this tender.</p>
      </div>

      {isLoading ? (
        <div className="py-20 flex justify-center"><Loader2 className="w-8 h-8 animate-spin" /></div>
      ) : (
        <div className="grid gap-4">
          {suppliers?.map((supplier) => {
            const isSelected = selectedSuppliers.includes(supplier.id);
            return (
              <div 
                key={supplier.id}
                onClick={() => toggleSupplier(supplier.id)}
                className={clsx(
                  "flex items-center gap-6 p-6 rounded-xl border-2 transition-all cursor-pointer bg-card hover:shadow-md",
                  isSelected 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/30"
                )}
              >
                <div className="w-16 h-16 rounded-lg bg-white border border-border flex items-center justify-center shrink-0">
                  {supplier.logoUrl ? (
                    <img src={supplier.logoUrl} alt={supplier.name} className="w-full h-full object-contain p-2" />
                  ) : (
                    <Building2 className="w-8 h-8 text-muted-foreground" />
                  )}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-bold text-foreground">{supplier.name}</h3>
                    {supplier.isPreferred && (
                      <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-bold uppercase">
                        Preferred
                      </span>
                    )}
                  </div>
                  <p className="text-muted-foreground text-sm mb-2">{supplier.description}</p>
                  <div className="flex items-center gap-1 text-yellow-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={clsx("w-4 h-4", i < (supplier.rating || 0) ? "fill-current" : "text-gray-300")} />
                    ))}
                    <span className="text-sm text-muted-foreground ml-2 text-gray-500">({supplier.rating}.0)</span>
                  </div>
                </div>

                <div className={clsx(
                  "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
                  isSelected ? "bg-primary border-primary text-primary-foreground" : "border-muted-foreground"
                )}>
                  {isSelected && <CheckCircle2 className="w-4 h-4" />}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="flex justify-between pt-8 border-t border-border mt-8">
        <Button variant="ghost" onClick={onBack}>
          <ChevronLeft className="mr-2 w-4 h-4" /> Back to Spec
        </Button>
        <Button 
          onClick={onNext} 
          disabled={selectedSuppliers.length === 0}
          size="lg"
        >
          Review Summary <ChevronRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
